# Welcome To Pneumaturgy

https://www.google.com.ec/books/edition/The_Rule_of_S_Benet/L616EIVDc3kC?hl=en&gbpv=1&printsec=frontcover

# pneu·ma

/ˈno͞omə/

[](data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiI+CiAgPGRlZnM+CiAgICA8cG9seWdvbiBpZD0ic21hbGwtdmlzZW1lLXYzLWEiIHBvaW50cz0iMCAwIDMyIDAgMzIgMzIgMCAzMiIvPgogIDwvZGVmcz4KICA8ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgPG1hc2sgaWQ9InNtYWxsLXZpc2VtZS12My1iIiBmaWxsPSIjZmZmIj4KICAgICAgPHVzZSB4bGluazpocmVmPSIjc21hbGwtdmlzZW1lLXYzLWEiLz4KICAgIDwvbWFzaz4KICAgIDx1c2UgZmlsbD0iIzQyODVGNCIgeGxpbms6aHJlZj0iI3NtYWxsLXZpc2VtZS12My1hIi8+CiAgICA8cGF0aCBmaWxsPSIjRDJFM0ZDIiBkPSJNMCwxNS4yMzk3OTYzIEMyLjU0Mzg1NzE0LDE4Ljg3MDUyMDMgNS42NTIsMjIuMDgyMTk0NiA5LjIwMjI4NTcxLDI0Ljc0NDg3NjkgQzEzLjIxMTU3MTQsMjcuNzUxNzA3NyAxOC43ODg0Mjg2LDI3Ljc1MTcwNzcgMjIuNzk3NzE0MywyNC43NDQ4NzY5IEMyNi4zNDgsMjIuMDgyMTk0NiAyOS40NTYxNDI5LDE4Ljg3MDUyMDMgMzIsMTUuMjM5Nzk2MyBMMzIsLTcgTDAsLTcgTDAsMTUuMjM5Nzk2MyBaIiBtYXNrPSJ1cmwoI3NtYWxsLXZpc2VtZS12My1iKSIvPgogICAgPHBhdGggZmlsbD0iIzQyODVGNCIgZmlsbC1vcGFjaXR5PSIuNiIgZD0iTTE2LDIxLjIzMDY0OTIgQzE2LjkyNjA5OTEsMjEuMjMwNjQ5MiAxNy43OTEyNDY3LDIxLjQ5NDMxNTcgMTguNTI3MjEzNSwyMS45NTE1MDE5IEMxOC44MTA0NDEsMjIuMTI3MzMwOSAxOS4xMzYyNzM4LDIxLjc4ODc0ODUgMTguOTQwMzc5OSwyMS41MTY0Njc0IEMxOC4yNzg1NTU2LDIwLjU5NzMyNjMgMTcuMjA4MTEzNiwyMCAxNiwyMCBDMTQuNzkxODg2NCwyMCAxMy43MjE0NDQ0LDIwLjU5NzMyNjMgMTMuMDU5NjIwMSwyMS41MTY0Njc0IEMxMi44NjM3MjYyLDIxLjc4ODc0ODUgMTMuMTg5NTU5LDIyLjEyNzMzMDkgMTMuNDcyNzg2NSwyMS45NTE1MDE5IEMxNC4yMDg3NTMzLDIxLjQ5NDMxNTcgMTUuMDczOTAwOSwyMS4yMzA2NDkyIDE2LDIxLjIzMDY0OTIiIG1hc2s9InVybCgjc21hbGwtdmlzZW1lLXYzLWIpIi8+CiAgICA8cGF0aCBzdHJva2U9IiM0Mjg1RjQiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIGQ9Ik0yNSwxMyBDMjMsMTUuMzMzMzMzMyAyMCwxNi41IDE2LDE2LjUgQzEyLDE2LjUgOSwxNS4zMzMzMzMzIDcsMTMgTDEzLDEwLjUgTDE5LDEwLjUgTDI1LDEzIFoiIG1hc2s9InVybCgjc21hbGwtdmlzZW1lLXYzLWIpIi8+CiAgICA8cG9seWdvbiBmaWxsPSIjNDI4NUY0IiBmaWxsLXJ1bGU9Im5vbnplcm8iIHBvaW50cz0iOCAxNCA3IDEzIDI1IDEzIDI0IDE0IiBtYXNrPSJ1cmwoI3NtYWxsLXZpc2VtZS12My1iKSIvPgogICAgPHBhdGggc3Ryb2tlPSIjNDI4NUY0IiBzdHJva2UtbGluZWNhcD0icm91bmQiIGQ9Ik0yMCwzIEwxNy43Njc4NzUsNS4yNTg5MjYyMiBDMTYuNzkxNSw2LjI0NzAyNDU5IDE1LjIwODUsNi4yNDcwMjQ1OSAxNC4yMzIxMjUsNS4yNTg5MjYyMiBMMTIsMyIgbWFzaz0idXJsKCNzbWFsbC12aXNlbWUtdjMtYikiLz4KICA8L2c+Cjwvc3ZnPgo=)

*noun*

**PHILOSOPHY**

(in Stoic thought) the vital spirit, soul, or creative force of a person.

# (t)urgy

[*ἔργον*](https://en.wiktionary.org/wiki/%E1%BC%94%CF%81%CE%B3%CE%BF%CE%BD#Ancient_Greek) (*érgon*, “work”)

[](data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiI+CiAgPGRlZnM+CiAgICA8cG9seWdvbiBpZD0ic21hbGwtdmlzZW1lLXYzLWEiIHBvaW50cz0iMCAwIDMyIDAgMzIgMzIgMCAzMiIvPgogIDwvZGVmcz4KICA8ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgPG1hc2sgaWQ9InNtYWxsLXZpc2VtZS12My1iIiBmaWxsPSIjZmZmIj4KICAgICAgPHVzZSB4bGluazpocmVmPSIjc21hbGwtdmlzZW1lLXYzLWEiLz4KICAgIDwvbWFzaz4KICAgIDx1c2UgZmlsbD0iIzQyODVGNCIgeGxpbms6aHJlZj0iI3NtYWxsLXZpc2VtZS12My1hIi8+CiAgICA8cGF0aCBmaWxsPSIjRDJFM0ZDIiBkPSJNMCwxNS4yMzk3OTYzIEMyLjU0Mzg1NzE0LDE4Ljg3MDUyMDMgNS42NTIsMjIuMDgyMTk0NiA5LjIwMjI4NTcxLDI0Ljc0NDg3NjkgQzEzLjIxMTU3MTQsMjcuNzUxNzA3NyAxOC43ODg0Mjg2LDI3Ljc1MTcwNzcgMjIuNzk3NzE0MywyNC43NDQ4NzY5IEMyNi4zNDgsMjIuMDgyMTk0NiAyOS40NTYxNDI5LDE4Ljg3MDUyMDMgMzIsMTUuMjM5Nzk2MyBMMzIsLTcgTDAsLTcgTDAsMTUuMjM5Nzk2MyBaIiBtYXNrPSJ1cmwoI3NtYWxsLXZpc2VtZS12My1iKSIvPgogICAgPHBhdGggZmlsbD0iIzQyODVGNCIgZmlsbC1vcGFjaXR5PSIuNiIgZD0iTTE2LDIxLjIzMDY0OTIgQzE2LjkyNjA5OTEsMjEuMjMwNjQ5MiAxNy43OTEyNDY3LDIxLjQ5NDMxNTcgMTguNTI3MjEzNSwyMS45NTE1MDE5IEMxOC44MTA0NDEsMjIuMTI3MzMwOSAxOS4xMzYyNzM4LDIxLjc4ODc0ODUgMTguOTQwMzc5OSwyMS41MTY0Njc0IEMxOC4yNzg1NTU2LDIwLjU5NzMyNjMgMTcuMjA4MTEzNiwyMCAxNiwyMCBDMTQuNzkxODg2NCwyMCAxMy43MjE0NDQ0LDIwLjU5NzMyNjMgMTMuMDU5NjIwMSwyMS41MTY0Njc0IEMxMi44NjM3MjYyLDIxLjc4ODc0ODUgMTMuMTg5NTU5LDIyLjEyNzMzMDkgMTMuNDcyNzg2NSwyMS45NTE1MDE5IEMxNC4yMDg3NTMzLDIxLjQ5NDMxNTcgMTUuMDczOTAwOSwyMS4yMzA2NDkyIDE2LDIxLjIzMDY0OTIiIG1hc2s9InVybCgjc21hbGwtdmlzZW1lLXYzLWIpIi8+CiAgICA8cGF0aCBzdHJva2U9IiM0Mjg1RjQiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiIGQ9Ik0yNSwxMyBDMjMsMTUuMzMzMzMzMyAyMCwxNi41IDE2LDE2LjUgQzEyLDE2LjUgOSwxNS4zMzMzMzMzIDcsMTMgTDEzLDEwLjUgTDE5LDEwLjUgTDI1LDEzIFoiIG1hc2s9InVybCgjc21hbGwtdmlzZW1lLXYzLWIpIi8+CiAgICA8cG9seWdvbiBmaWxsPSIjNDI4NUY0IiBmaWxsLXJ1bGU9Im5vbnplcm8iIHBvaW50cz0iOCAxNCA3IDEzIDI1IDEzIDI0IDE0IiBtYXNrPSJ1cmwoI3NtYWxsLXZpc2VtZS12My1iKSIvPgogICAgPHBhdGggc3Ryb2tlPSIjNDI4NUY0IiBzdHJva2UtbGluZWNhcD0icm91bmQiIGQ9Ik0yMCwzIEwxNy43Njc4NzUsNS4yNTg5MjYyMiBDMTYuNzkxNSw2LjI0NzAyNDU5IDE1LjIwODUsNi4yNDcwMjQ1OSAxNC4yMzIxMjUsNS4yNTg5MjYyMiBMMTIsMyIgbWFzaz0idXJsKCNzbWFsbC12aXNlbWUtdjMtYikiLz4KICA8L2c+Cjwvc3ZnPgo=)

*suffix*

**GREEK**

a combining form occurring in loanwords from Greek, where it meant **“work”;** A technique for working with something.

<aside>
<img src="https://app.notion.com/icons/geography_gray.svg" alt="https://app.notion.com/icons/geography_gray.svg" width="40px" /> **Culture**
*The connecting fibre all of us are connected to, are with threads of communication, teamwork, communication, and success.*

</aside>

<aside>
<img src="https://app.notion.com/icons/potted-plant_gray.svg" alt="https://app.notion.com/icons/potted-plant_gray.svg" width="40px" /> **Growth**
*With the correct mindset, we all ought to have the tools, motivation, and room to grow and refine our skills, to be our very best.*

</aside>

<aside>
<img src="https://app.notion.com/icons/fireworks_gray.svg" alt="https://app.notion.com/icons/fireworks_gray.svg" width="40px" /> **Spirit**
*We are creating for reasons greater than ourselves, and ought to be fitting vessels for the universe to create.*

</aside>

[Projects](Welcome%20To%20Pneumaturgy/Projects%209131773558c24d5db3e62ae0d1fdd6bb.csv)

# $Who \ are \ we?$

If you’re here, you’ve made what is widely considered to be a *bad decision:*

You have a full time job. You’ve tried and failed to start videogame projects previously. You are aware of the tremendous risk involved in terms of time investment. You understand the gigantic amount of effort required in the multiple disciplines involved in game design.

**Despite it all, you’re willing to make these sacrifices to chase a dream, because you have a story you want to tell the world. *That’s who we are.***

# $How\ is \ this \ going \ to \ be \ any \ different?$

# Because of our Culture

**When you tell people you’re starting something, without having everything figured out, they’ll call you a fool.** When you tell people that you’re going to go into gamedev without a clear mission or “goal” in sight, having already resolved how you will finish your game, how you will market and publish it, they will be shocked, and laugh at you.

Yet, that is precisely the attitude of Pneumaturgy. It requires a belief that the best ideas don’t live inside our heads, but are born when we share. Therefore, we must only focus in refining our skills, being the best developers we can be. That great game, project, idea is waiting out there; waiting for the right team to bring it into reality.

# Because the Time is Right

**There has never been a better time to get into gamedev.** The triple AAA studios are laying off their seniors, and are focusing on *commercialising the medium;* that opens the playing field for people to make honest-to-god games.

Engines like Unity and Unreal are large but more bureocratic, slow, and buggy. Godot is a “young man” in the game engine scene, very young, but still fully equipped with the most important aspects since the latest update. It is also open source, so we can expect this scene to grow exponentially, as these laid-off seniors and disenfranchised studios turn to more scalable software.

# Because of our Resources

**You might be thinking; we have no time and no money. What resources?** Our biggest riches, obviously, are in our people. We have some incredible minds with extensive experience in best practices of code, and logical thinking.

But that’s not all. These people are all also willing to commit to a dream, with a result that is bigger than themselves; that is priceless. Having a full time job, and working on the side as a hobby, means we have no stakeholders or publishers to suck up to. No rushed deadlines, no following trends, no chasing wallets. We also will have a readily active mind, never will we be stuck on endless problems, because our mind is used every day for taking on responsibilities, finishing tasks, and working with other people. 

# $How \ do \ we \ resolve \ conflict?$

Open source projects and governments have a similar structure:

<aside>
<img src="https://app.notion.com/icons/accessibility_gray.svg" alt="https://app.notion.com/icons/accessibility_gray.svg" width="40px" /> The people (consumers) are represented by a president (community manager)

</aside>

<aside>
<img src="https://app.notion.com/icons/graduate_gray.svg" alt="https://app.notion.com/icons/graduate_gray.svg" width="40px" /> The educated law-makers (code writers) contribute to the project (state)

</aside>

<aside>
<img src="https://app.notion.com/icons/gavel_gray.svg" alt="https://app.notion.com/icons/gavel_gray.svg" width="40px" /> A moderating body (moderators) ensures that the constitution is upheld

</aside>

<aside>
<img src="https://app.notion.com/icons/ghost_gray.svg" alt="https://app.notion.com/icons/ghost_gray.svg" width="40px" /> A shaman or high priest ensures that all decisions comply with consciousness

</aside>

The goal is that each of us should learn and master leadership skills, have empathy for each other, and have honest conversations to resolve disagreements. If one is demeed to carry insufficient empathy to hear other opinions except their own, their opinion is not respected.

# $Ok... \ What\ about\ the \ money?$

So far we have talked very idealistically about this project, because fundamentally, we are putting art and refining our skills above the monitary gain. However, that doesn’t mean we may be broke forever. 

Games are an incredibly risky investment. Companies that rely entirely on this medium to make an income do so with a very understandable set of requirements. Publishers will demand that the game is done in less than 2 years, in order to ensure a quick return on that investment. They will also ensure that you can *guarantee* your game will sell, by using data science to find trends which you can fulfill. This process is dignified, but it is soulless, and that which has no soul, no life, cannot last for very long.

True success is in innovation. Think Disney, Apple, Nintendo; they do not follow trends, they set them. They have no stakeholders to please, no publishers to set expectations for. And although they are globally successful, they still occasionally fail.

We have the tools in place to develop our skills, and create something truly incredible and innovative. The worst case scenario, we learn a lot of cool skills. Best case scenario, we break out, make a ton of money, and quit our jobs. A generation of volatile startups have taught us that life is too short to not try and do something different. 

# $How \ we \ work$

We meet two times a week, currently on Tuesday and Wednesday. Occasionally, we may meet on the weekend for an event, an educational meeting, or simply to hang out. 

When working together, we do circular pairing; that is one navigator and one driver, and as features are finished, a new driver is chosen and the previous driver becomes the navigator.