# Original Concept

# Foundational Concept: AutoChess

This game will essentially be an autochess; inspired by games such as TFT, Super Auto Chess and more.

Hero - has a set of moves

Enemy - has another set of moves

Takes turn hitting each other until one dies.

It is entirely sequential, not live.

# Supplemental Concept: Slice&Dice

Each entity has a “dice” -  the amout of sides the dice has depends on their level. Each hero has a set moveset for their dice, but through items, they can be modified. Each turn, the hero will roll their die, to use either one of those moves.

# Supplemental Concept: AR

Like Pokemon go, you find these entities on the street. Or, you can trade them, or maybe in some case buy them. When you pass by someone on the street who has the app, you battle them. Otherwise, you battle random opponents, like superautopets.

# Unique Concept: Full Fight

When encountering someone, you have the option to turn it into a full fight, meaning you keep fightinng each other until one of you completely loses their life.

# Unique Concept: AI Generated

Each fighter is randomly generated, but will retain a level (rarity) and a class.

# Unique Concept: Abilities, Spells

Abilities or spells come from equipped items. some of them require mana to cast, which can be generated from people.

# Unique Concept: Personal Progression

Your own player character will have a set health and xp, that corresponds to the number of teammates they can have, starting with just one. think super auto pets. Since you will have many saved heroes, you can always swap them around every fight.