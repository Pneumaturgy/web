# Classes

Sure, let's create an example involving propositions and use each of the 10 logical forms. We'll use the following propositions for our example:

- \( P \): "It is raining."
- \( Q \): "The ground is wet."
- \( R \): "The sun is shining."
- \( S \): "It is cloudy."

Modus type  - tanks

### 1. Modus Ponens - Buff

**Form**:

- \( P \rightarrow Q \)
- \( P \)
- Therefore, \( Q \)

**Example**:

- If it is raining, then the ground is wet.
- It is raining.
- Therefore, the ground is wet.

### 2. Modus Tollens - Defend

**Form**:

- \( P \rightarrow Q \)
- \( \neg Q \)
- Therefore, \( \neg P \)

**Example**:

- If it is raining, then the ground is wet.
- The ground is not wet.
- Therefore, it is not raining.

Syllogism type - healers

### 3. Disjunctive Syllogism - dark health

**Form**:

- \( P \vee Q \)
- \( \neg P \)
- Therefore, \( Q \)

**Example**:

- It is raining or the sun is shining.
- It is not raining.
- Therefore, the sun is shining.

### 4. Hypothetical Syllogism - pure health

**Form**:

- \( P \rightarrow Q \)
- \( Q \rightarrow R \)
- Therefore, \( P \rightarrow R \)

**Example**:

- If it is raining, then the ground is wet.
- If the ground is wet, then it is slippery.
- Therefore, if it is raining, then it is slippery.

Dilemma type - magicians

### 5. Constructive Dilemma - pure magic

**Form**:

- \( P \rightarrow Q \)
- \( R \rightarrow S \)
- \( P \vee R \)
- Therefore, \( Q \vee S \)

**Example**:

- If it is raining, then the ground is wet.
- If the sun is shining, then it is hot.
- It is raining or the sun is shining.
- Therefore, the ground is wet or it is hot.

### 6. Destructive Dilemma - dark magic

**Form**:

- \( P \rightarrow Q \)
- \( R \rightarrow S \)
- \( \neg Q \vee \neg S \)
- Therefore, \( \neg P \vee \neg R \)

**Example**:

- If it is raining, then the ground is wet.
- If the sun is shining, then it is hot.
- The ground is not wet or it is not hot.
- Therefore, it is not raining or the sun is not shining.

Operand type - warriors

### 7. Simplification - normal attack

**Form**:

- \( P \land Q \)
- Therefore, \( P \)
- Therefore, \( Q \)

**Example**:

- It is raining and the ground is wet.
- Therefore, it is raining.
- Therefore, the ground is wet.

### 8. Conjunction - special attack

**Form**:

- \( P \)
- \( Q \)
- Therefore, \( P \land Q \)

**Example**:

- It is raining.
- The ground is wet.
- Therefore, it is raining and the ground is wet.

### 9. Addition - ranged / multi attack

**Form**:

- \( P \)
- Therefore, \( P \vee Q \)

**Example**:

- It is raining.
- Therefore, it is raining or the sun is shining.

Biconditional type - thieves

### 10. Biconditional Introduction - crowd control

**Form**:

- \( P \rightarrow Q \)
- \( Q \rightarrow P \)
- Therefore, \( P \leftrightarrow Q \)

**Example**:

- If it is raining, then the ground is wet.
- If the ground is wet, then it is raining.
- Therefore, it is raining if and only if the ground is wet.

### 11. Biconditional Elimination - debuff

**Form**:

- \( P \leftrightarrow Q \)
- Therefore, \( P \rightarrow Q \)
- Therefore, \( Q \rightarrow P \)

**Example**:

- It is raining if and only if the ground is wet.
- Therefore, if it is raining, then the ground is wet.
- Therefore, if the ground is wet, then it is raining.

By using these logical forms, you can construct a variety of logical arguments and see how different propositions relate to one another.

Here are the definitions of those terms:

1. **Modus**:
    - **Definition**: The term "modus" comes from Latin and means "mode" or "manner." In logic, it is often used in the names of argument forms to describe the manner in which the inference is made.
    - **Examples**: Modus Ponens (the mode of affirming) and Modus Tollens (the mode of denying).

Buff, defend

1. **Syllogism**:
    - **Definition**: A syllogism is a form of reasoning in which a conclusion is drawn from two given or assumed propositions (premises). Each premise shares a common term with the conclusion.
    - **Example**:
        - Major premise: All humans are mortal.
        - Minor premise: Socrates is human.
        - Conclusion: Socrates is mortal.

Health

1. **Dilemma**:
    - **Definition**: A dilemma is a type of argument involving two or more conditional (if-then) statements that lead to an undesirable outcome. It forces a choice between two or more alternatives, each of which has significant consequences.
    - **Example**:
        - If we increase taxes, people will be unhappy.
        - If we don't increase taxes, we can't fund public services.
        - Either we increase taxes or we don't increase taxes.
        - Therefore, either people will be unhappy or we can't fund public services.

Special attack

1. **Operand**:
    - **Definition**: An operand is a quantity on which an operation is performed. In logic and mathematics, it refers to the objects of logical or mathematical operations.
    - **Example**: In the logical expression \( P \land Q \), \( P \) and \( Q \) are operands, and \( \land \) (AND) is the operator.

Magic

1. **Biconditional**:
    - **Definition**: A biconditional is a logical connective that states that two propositions are both true or both false. It is often expressed as "if and only if."
    - **Example**: \( P \leftrightarrow Q \) means \( P \) is true if and only if \( Q \) is true. If it is raining, then the ground is wet, and if the ground is wet, then it is raining.

Attack