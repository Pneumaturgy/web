# Closed Projects

Created: July 13, 2024 11:18 AM
Sub-item: Cerdo (Cerdo%20cf0a9a1a7dd24d28a9eb760c9177cd55.md), PneuMath (PneuMath%20f439912d40f94022b7e01cf0341063d5.md), GMTK Game Jam (GMTK%20Game%20Jam%20699434d1929c41fb9f0234d59b4bd459.md)