# LifeTracker

Created: August 20, 2024 3:34 PM
Parent item: Design Docs (Design%20Docs%20c0363ac2bbb44d61a241627ceadfc453.md)

It’s a time tracker for things

tracks diets, weight, exercise, etc nased on info you put

you can write lore

make quests to get things liek groceries

they give you points for shit

Maybe the food you input gets you a rough idea of the vitamins etc that you have, and LLM can suggest your next meal