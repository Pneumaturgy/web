# Pneuma Knights

Created: July 13, 2024 4:51 PM
Link: https://docs.google.com/document/d/1w635j4DAkOwRYjL4AGsxnFsfcrL3GB94Eme8NHEOoUI/edit#heading=h.689pbr44gy3p
Parent item: Design Docs (Design%20Docs%20c0363ac2bbb44d61a241627ceadfc453.md)
Sub-item: Nico’s Story Proposal (Nico%E2%80%99s%20Story%20Proposal%20211f3846aab64647ab6ef501e44b8f00.md), Por Nada (Por%20Nada%202762120d79d9464ebc1f795ea4a1e09b.md), Rapha’s Story (Rapha%E2%80%99s%20Story%2061c6b0c7425f4fdaa016fb0ea9646e16.md)

# PneumaKnights

*You wake up in a drop pod falling from the sky onto a strange planet. As you emerge from the drop pod, you find yourself in a mech suit, surrounded by a strange planet rich in resources. **Who are you? What is this strange world? How did I get here?** You reach into your crashed drop pod and pull out a <random> weapon. **Now you must survive!***

- 2d, top down 3rd person view (like Factorio)
- Procedurally generated world
- Day/Night Cycle (like Minecraft)
- World is peaceful by day (*at least for now…*) and dangerous by night (*things that seemed inanimate by day now suddenly want to kill you?*)
- Gather resources from your environment to upgrade your gear / build your army of drones
- Discover other procedurally generated (but not all of them, see below) mechs just like yours, some are dead and some are alive (*and if alive they definitely want to kill you*)
    - Find and research new (random) parts for your mech via what you scavenge from those mechs (once they are dead)
- Build and maintain a group of autonomous drones to help you gather resources and defend yourself
- On death, explode into a bunch of pixels and choose what item(s) (based on some sort of point system/power level -- ie I can take a bunch of weak items or a single strong item, basically every item has a power rating and you can take up to X power rating with you into the next life) to take with you into the next life. ***Is this a simulation? How can I escape?***
    - Intro plays again and you are now playing a new game, but instead of a random weapon (unless you took nothing from the previous life), you find your saved items from your previous run in the drop pod.
- Find a secret set of powerful Arthurian Artifacts scattered throughout the world *to escape the simulation* and ***discover what is really going on***
- Find and fight past versions of yourself (these are the mechs that are not procedurally generated)
- Your mech suit has multiple slots for items/artifacts. Only a single slot can be controlled at a time (for a powerful effect), all other slots are automated with a weaker effect. Overtime as you fill all the slots, you may discover powerful synergies between slots/artifacts to the point where the combination of your automated slots is stronger than your single selected manual slot at which point you are encouraged to pick your weakest slot/item combination as your manual slot, to let the automation do all the work as you run around the map exploring and fighting everything out to kill you.